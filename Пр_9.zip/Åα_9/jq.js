$interval(function(){$scope.question = new Date()}, 1000);
//$interval.cancel(promise)